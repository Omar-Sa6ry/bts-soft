# @bts-soft/upload

An enterprise-grade media orchestration and chunked upload library for NestJS and GraphQL. Designed with clean architecture, the package leverages design patterns (Strategy, Command, Observer) to manage complex file lifecycles with modularity, high performance, and security. It supports multi-provider storage, distributed rate limiting via Redis, asynchronous chunk merging using BullMQ, Server-Sent Events (SSE) for progress streaming, and CDN URL rewriting.

---

## Features

- **Multi-Provider Architecture**: Seamlessly switch between Local Disk storage and Cloudinary at runtime using configuration.
- **Resumable Chunked Uploads**: Native support for large file uploads split into smaller chunks, tracking progress and merging files asynchronously.
- **Distributed Rate Limiting**: Token Bucket rate-limiting algorithm backed by Redis with a transparent in-memory fallback.
- **Asynchronous Queue Processing**: Integrates with BullMQ to perform intensive chunk merging off the main thread.
- **Real-Time Progress Streaming**: Uses Server-Sent Events (SSE) to broadcast merge and upload progress directly to the client.
- **CDN Integration**: Built-in support for rewriting and routing asset URLs via CDNs.
- **Webhook Observers**: Handles background processing notifications from third-party storage providers.
- **Strict Input Validation**: Automatic validation of file extensions, MIME types, and file sizes before ingestion.
- **Design Patterns Driven**:
  - **Strategy Pattern**: Decouples upload and delete implementations from the application core.
  - **Command Pattern**: Encapsulates operations inside safe, transactional commands.
  - **Observer Pattern**: Broadcasts file lifecycle events (upload start, success, fail, delete) to custom observers.
- **Protocol Agnostic**: Supports both REST (Express/Multer) and GraphQL (graphql-upload) APIs.

---

## System Architecture

```mermaid
flowchart TD
    Client[Client Request] --> RL[RateLimiterService - Token Bucket]
    RL -->|Allowed| Val[FileValidatorService]
    RL -->|Rate Limited| E429[HTTP 429 Too Many Requests]
    
    Val -->|REST / GraphQL| Ctrl[Upload Controllers]
    Val -->|Invalid| E400[HTTP 400 Bad Request]
    
    Ctrl -->|Single File| US[UploadService]
    Ctrl -->|Chunks| CUS[ChunkedUploadService]
    
    US --> Cmd[Upload Commands]
    Cmd --> Strat[Upload Strategies - Local / Cloudinary]
    Strat --> Store[Storage Provider]
    
    CUS --> LCS[LocalChunkStorage]
    LCS -->|Last Chunk Received| UQS[UploadQueueService]
    UQS -->|Enqueue Job| BMQ[BullMQ Queue]
    
    BMQ --> Proc[UploadProcessor]
    Proc --> Merge[Merge Chunks]
    Merge --> Cmd
    
    Proc -.->|Progress Update| JS[UploadJobService]
    JS -.->|SSE Stream| SSE[Server-Sent Events Controller]
    SSE -.->|Progress Updates| Client
```

---

## Installation

Install the package via npm:

```bash
npm install @bts-soft/upload
```

### Peer Dependencies

Ensure you have the following peer dependencies installed in your NestJS project:

```json
{
  "peerDependencies": {
    "@nestjs/common": ">=11.0.0",
    "@nestjs/config": ">=4.0.0",
    "@nestjs/core": ">=11.0.0",
    "@nestjs/graphql": ">=13.0.0"
  }
}
```

---

## Configuration

The package registers config variables dynamically and validates them against a strict schema during startup. Make sure to define the following environment variables.

### Global Settings

| Variable | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `UPLOAD_PROVIDER` | `local` \| `cloudinary` | `local` | Storage provider strategy to use. |
| `UPLOAD_MAX_IMAGE_SIZE` | number (bytes) | `5242880` (5MB) | Maximum file size for image uploads. |
| `UPLOAD_MAX_VIDEO_SIZE` | number (bytes) | `104857600` (100MB) | Maximum file size for video uploads. |
| `UPLOAD_MAX_AUDIO_SIZE` | number (bytes) | `52428800` (50MB) | Maximum file size for audio uploads. |
| `UPLOAD_MAX_FILE_SIZE` | number (bytes) | `10485760` (10MB) | Maximum file size for documents/raw files. |
| `UPLOAD_MAX_MODEL_3D_SIZE` | number (bytes) | `104857600` (100MB) | Maximum file size for 3D models. |

### Distributed Rate Limiting (Token Bucket)

| Variable | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `UPLOAD_RATE_LIMIT_CAPACITY` | number | `10` | Maximum token bucket size for chunked uploads. |
| `UPLOAD_RATE_LIMIT_REFILL_RATE`| number | `2` | Number of tokens refilled per second. |

### Local Storage Settings

Required if `UPLOAD_PROVIDER=local`:

| Variable | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `UPLOAD_LOCAL_PATH` | string | `./uploads` | Absolute or relative path to store files. |

### Cloudinary Storage Settings

Required if `UPLOAD_PROVIDER=cloudinary`:

| Variable | Type | Description |
| :--- | :--- | :--- |
| `CLOUDINARY_CLOUD_NAME` | string | Cloudinary account cloud name. |
| `CLOUDINARY_API_KEY` | string | Cloudinary API Key. |
| `CLOUDINARY_API_SECRET` | string | Cloudinary API Secret. |

---

## Architecture Details

### 1. Token Bucket Rate Limiting
To prevent Denial of Service (DoS) attacks on upload endpoints, the package implements the **Token Bucket** algorithm via the `RateLimiterService`. 
- **Distributed State**: When `@bts-soft/cache` is imported and configured with Redis, the token bucket state is stored in Redis to enforce rate limits across multiple container instances.
- **In-Memory Fallback**: If Redis is not configured or becomes unavailable, the rate limiter automatically falls back to local memory without throwing exceptions.

### 2. Resumable Chunked Uploads
The chunked upload workflow operates as follows:
1. **Initiate Job**: The client calls `/upload/chunk/initiate` with metadata (filename, size, type). The `UploadJobService` registers an upload job with a unique `jobId`.
2. **Upload Chunks**: The client uploads chunks concurrently or sequentially using `/upload/chunk/upload`. The `IChunkStorage` (backed by `LocalChunkStorage`) stores parts on disk.
3. **Queue Merge**: Once the final chunk is verified, the system transfers the assembly task to `UploadQueueService` using BullMQ.
4. **Merge and Clean**: The `UploadProcessor` processes the task asynchronously, concatenating chunks on disk, validating the final file hash, invoking the correct command strategy, and cleaning up temporary chunks.

### 3. Server-Sent Events (SSE)
Since chunked merging and provider synchronization (e.g. sending large video files to Cloudinary) can take time, the package exposes a Server-Sent Events (SSE) streaming endpoint:
```http
GET /upload/jobs/:jobId/stream
```
This endpoint streams progress values (`0` to `100`), status updates (`processing`, `completed`, `failed`), and the final asset `url` directly to client UIs.

---

## Usage

### 1. Registering the Module

Import `UploadModule` into your root application module. The module registers its dependencies automatically.

```typescript
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { UploadModule } from '@bts-soft/upload';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    UploadModule,
  ],
})
export class AppModule {}
```

### 2. REST API Controller Example

Inject `UploadService` or `ChunkedUploadService` into your NestJS controllers:

```typescript
import { Controller, Post, UploadedFile, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { UploadService } from '@bts-soft/upload';
import { Readable } from 'stream';

@Controller('media')
export class MediaController {
  constructor(private readonly uploadService: UploadService) {}

  @Post('image')
  @UseInterceptors(FileInterceptor('file'))
  async uploadImage(@UploadedFile() file: Express.Multer.File) {
    const stream = Readable.from(file.buffer);
    
    return this.uploadService.uploadImageCore({
      stream,
      filename: file.originalname,
      size: file.size,
    });
  }
}
```

### 3. GraphQL Resolver Example

Utilize `UploadService` in a GraphQL resolver using types exported by the package:

```typescript
import { Resolver, Mutation, Args } from '@nestjs/graphql';
import { UploadService, CreateImageDto } from '@bts-soft/upload';

@Resolver()
export class MediaResolver {
  constructor(private readonly uploadService: UploadService) {}

  @Mutation(() => String)
  async uploadImage(@Args('input') input: CreateImageDto) {
    const result = await this.uploadService.uploadImage(input);
    return result.url;
  }
}
```

### 4. Custom Lifecycle Observers

You can register custom observers to react to upload/delete events (e.g., to write to a database, send statistics, or track security audits).

Create a service implementing `IUploadObserver`:

```typescript
import { Injectable, OnModuleInit } from '@nestjs/common';
import { IUploadObserver, UploadObserverManager } from '@bts-soft/upload';

@Injectable()
export class FileAuditService implements IUploadObserver, OnModuleInit {
  constructor(private readonly observerManager: UploadObserverManager) {}

  onModuleInit() {
    this.observerManager.register(this);
  }

  async onUploadSuccess(url: string, type: string, metadata?: any): Promise<void> {
    console.log(`Asset uploaded successfully: ${url} (Type: ${type})`);
  }

  async onUploadFail(error: Error, metadata?: any): Promise<void> {
    console.error(`Asset upload failed: ${error.message}`);
  }

  async onDeleteSuccess(url: string): Promise<void> {
    console.log(`Asset deleted successfully: ${url}`);
  }

  async onDeleteFail(error: Error, url: string): Promise<void> {
    console.error(`Failed to delete asset ${url}: ${error.message}`);
  }
}
```

---

## API Reference

### UploadService

Directly uploads files using strategies.

- `uploadImageCore(file: UploadStreamInput): Promise<UploadResult>`
- `uploadVideoCore(file: UploadStreamInput): Promise<UploadResult>`
- `uploadAudioCore(file: UploadStreamInput): Promise<UploadResult>`
- `uploadFileCore(file: UploadStreamInput): Promise<UploadResult>`
- `uploadModel3dCore(file: UploadStreamInput): Promise<UploadResult>`
- `deleteImage(url: string): Promise<boolean>`
- `deleteVideo(url: string): Promise<boolean>`
- `deleteAudio(url: string): Promise<boolean>`
- `deleteFile(url: string): Promise<boolean>`

### ChunkedUploadService

Manages state and storage for chunked uploads.

- `initiateJob(filename: string, size: number, type: string, fileHash?: string, userId?: string): Promise<{ jobId: string, status: string }>`
- `uploadChunk(jobId: string, chunkIndex: number, totalChunks: number, file: Express.Multer.File, fileHash?: string, userId?: string): Promise<{ progress: number, completed: boolean }>`

### RateLimiterService

Enforces Token Bucket rate limiting.

- `consume(key: string): Promise<boolean>`: Consumes one token from the bucket identified by `key`. Returns `true` if consumed, `false` if rate-limited.

---

## Testing

The library includes unit and E2E test suites with fully mocked network and database dependencies alongside physical file cleanup.

```bash
# Run unit tests
npm run test

# Run e2e integration tests
npm run test:e2e

# Run test coverage
npm run test:cov
```

---

## License

MIT © BTS Soft - Developed by Omar Sabry.